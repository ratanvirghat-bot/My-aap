# Growth49 website starter

This is the first deployable project foundation for Growth49 (Marathi + English landing page, signup/login wiring, and Supabase database schema). It is **not yet a live production site** and does not collect payments or pay rewards. Admin dashboard, student dashboard pages, proof uploads, secure approval functions and payment gateway integration must be completed/configured before launch.

## 1. Free hosting
1. A parent/guardian or legally eligible adult should create the hosting and database accounts and review the business/payment model.
2. Create a free Supabase project at https://supabase.com.
3. In Supabase > SQL Editor, run `supabase/schema.sql`.
4. In Supabase > Authentication > URL Configuration, set your eventual site URL and allowed redirect URLs.
5. In `app.js`, replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_PUBLIC_KEY` with the Project URL and anon/public key from Supabase Project Settings > API.
   - The anon/public key may be used in the browser with correct Row Level Security.
   - NEVER put the `service_role` key, payment secret key, or passwords in `app.js` or any public file.
6. Publish the folder using Netlify Drop or connect a Git repository to Netlify. Netlify's free subdomain will look like `your-site-name.netlify.app`.
7. Test signup, email confirmation, login and RLS before inviting anyone.

## 2. What remains before real launch
- Build and secure the student dashboard and admin panel. Admin rights must be assigned server-side; never let a user set their own `role=admin`.
- Add private Storage buckets for payment and status proofs, with policies limiting access to the owner and authorized admins.
- Add server-side approval functions that atomically activate a student, create eligible referral credits, and approve a status reward. Prevent duplicate credits and self-referrals.
- Add campaign budgets, per-day limits, eligibility rules, refund/cancellation terms and clear payout terms. Rewards are not guaranteed income.
- Add a privacy notice, terms, contact/support details, data retention rules and an adult-reviewed compliance process.
- Verify age/eligibility and obtain parent/guardian involvement where legally required.

## 3. Payment gateway (later)
Do not paste API secrets into the website. A legally eligible adult/business owner should open a merchant account with a supported provider (for example Razorpay), complete KYC, and get the provider's approval. A developer then:
1. Creates a server-side checkout order using the provider's secret key stored only in server environment variables.
2. Opens the provider checkout from the site using the returned order ID.
3. Verifies the payment signature on the server.
4. Activates registration only after a verified webhook/server confirmation.
5. Stores only the gateway payment/order IDs and status needed for records; never store card/UPI PIN details.

Provider docs: https://razorpay.com/docs/

## 4. Current project contents
- `index.html` — responsive landing page and signup/login modal
- `style.css` — mobile-friendly dark dashboard-inspired visual design
- `app.js` — Supabase auth wiring placeholders
- `supabase/schema.sql` — starter tables and basic row-level security

Do not launch paid registration or reward withdrawals until all server-side security, gateway verification, legal review and admin workflows are completed.
