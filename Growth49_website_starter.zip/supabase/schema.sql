-- Growth49 initial database schema for Supabase.
-- Run in Supabase SQL Editor. Enable RLS; never expose service_role keys in browser code.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '',
 referral_code text unique,
 referred_by uuid references public.profiles(id),
 role text not null default 'student' check (role in ('student','admin')),
 status text not null default 'pending' check (status in ('pending','active','blocked')),
 created_at timestamptz not null default now()
);
create table if not exists public.payment_submissions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 amount_paise integer not null check (amount_paise = 4900),
 reference_note text,
 proof_path text,
 status text not null default 'pending' check (status in ('pending','approved','rejected')),
 reviewed_by uuid references public.profiles(id),
 reviewed_at timestamptz,
 created_at timestamptz not null default now()
);
create table if not exists public.courses (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text default '',
 video_url text,
 pdf_url text,
 is_published boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.status_tasks (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 instructions text not null,
 creative_url text,
 reward_paise integer not null default 500 check (reward_paise = 500),
 daily_limit integer not null default 0,
 is_active boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.status_submissions (
 id uuid primary key default gen_random_uuid(),
 task_id uuid not null references public.status_tasks(id),
 user_id uuid not null references public.profiles(id),
 proof_path text not null,
 status text not null default 'pending' check (status in ('pending','approved','rejected')),
 reviewed_by uuid references public.profiles(id),
 reviewed_at timestamptz,
 created_at timestamptz not null default now(),
 unique(task_id,user_id)
);
create table if not exists public.wallet_ledger (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 amount_paise integer not null,
 entry_type text not null check (entry_type in ('referral_reward','status_reward','withdrawal','adjustment')),
 description text not null,
 related_user_id uuid references public.profiles(id),
 created_at timestamptz not null default now()
);
create table if not exists public.withdrawal_requests (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 amount_paise integer not null check (amount_paise > 0),
 status text not null default 'pending' check (status in ('pending','approved','rejected','paid')),
 created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.payment_submissions enable row level security;
alter table public.courses enable row level security;
alter table public.status_tasks enable row level security;
alter table public.status_submissions enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.withdrawal_requests enable row level security;

-- A user may read/update only their own basic profile. Admin policies must be
-- added via a trusted role-management process, not by trusting client metadata.
create policy "profile self read" on public.profiles for select using (auth.uid() = id);
-- No client-side profile update policy: role/status/referral fields must only be changed by trusted server-side admin functions.
create policy "published courses read" on public.courses for select using (is_published = true);
create policy "active tasks read" on public.status_tasks for select using (is_active = true);
create policy "own payment submissions read" on public.payment_submissions for select using (auth.uid() = user_id);
create policy "own payment submissions insert" on public.payment_submissions for insert with check (auth.uid() = user_id);
create policy "own status submissions read" on public.status_submissions for select using (auth.uid() = user_id);
create policy "own status submissions insert" on public.status_submissions for insert with check (auth.uid() = user_id);
create policy "own ledger read" on public.wallet_ledger for select using (auth.uid() = user_id);
create policy "own withdrawals read" on public.withdrawal_requests for select using (auth.uid() = user_id);
create policy "own withdrawals insert" on public.withdrawal_requests for insert with check (auth.uid() = user_id);

-- Create profile rows for newly registered users.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name,referral_code)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),upper(substr(replace(gen_random_uuid()::text,'-',''),1,8)))
 on conflict(id) do nothing;
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
