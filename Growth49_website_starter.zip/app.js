// Configure these two public values after creating a Supabase project.
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_PUBLIC_KEY";
let client = null;
if (window.supabase && SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("YOUR_")) {
  client = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}
const modal=document.getElementById("authModal"), form=document.getElementById("authForm");
let mode="login", language="mr";
function showAuth(next){mode=next;modal.classList.add("show");document.getElementById("modalTitle").textContent=next==="signup"?"Create student account":"Student login";document.getElementById("nameLabel").hidden=next!=="signup";document.getElementById("refLabel").hidden=next!=="signup";document.getElementById("fullName").required=next==="signup";document.getElementById("authMessage").textContent="";}
["join"].forEach(id=>document.getElementById(id).addEventListener("click",()=>showAuth("signup")));
["loginTop","loginHero"].forEach(id=>document.getElementById(id).addEventListener("click",()=>showAuth("login")));
document.getElementById("close").onclick=()=>modal.classList.remove("show");
document.getElementById("lang").onclick=()=>{language=language==="mr"?"en":"mr";document.getElementById("lang").textContent=language==="mr"?"English":"मराठी";document.querySelectorAll("[data-en]").forEach(el=>el.textContent=el.dataset[language]);};
form.addEventListener("submit",async e=>{e.preventDefault();const msg=document.getElementById("authMessage");if(!client){msg.textContent="Setup pending: add Supabase URL and anon key in app.js. See README.";return;}const email=document.getElementById("email").value,password=document.getElementById("password").value;if(mode==="signup"){const full_name=document.getElementById("fullName").value.trim(),referral_code=document.getElementById("referral").value.trim();const {error}=await client.auth.signUp({email,password,options:{data:{full_name,referral_code}}});msg.textContent=error?error.message:"Account created. Check your email to confirm, then wait for admin activation."; }else{const {data,error}=await client.auth.signInWithPassword({email,password});if(error){msg.textContent=error.message;return;}const {data:profile}=await client.from("profiles").select("status,role").eq("id",data.user.id).single();msg.textContent=profile?.role==="admin"?"Admin account signed in. Connect the secured admin dashboard module before managing records.":profile?.status==="active"?"Login successful. Student dashboard module is ready to be connected.":"Your account is awaiting admin approval."; }});
